# 3D 无人机项目队友测试包

这个目录是给队友本地测试运行用的精简包，只保留前端运行所需内容，不包含算法数据集、实验输出、`node_modules` 和构建产物。

## 目录说明

```text
projects/
  drone-orchard/      # 本地 3D 可视化项目，默认运行在 5173
  mamba-agri-sim/     # 外层主站项目，默认运行在 5174，并在“三维控制”页面嵌入 5173
WEB_EMBED_HANDOFF.md
PROJECT_ADVANTAGE_DATA_REPORT.md
start-local.sh
start-local-windows.bat
```

## 环境要求

- Node.js 18 或更高版本
- npm

## 一键启动

macOS / Linux 在当前目录执行：

```bash
chmod +x start-local.sh
./start-local.sh
```

Windows 可直接双击：

```text
start-local-windows.bat
```

也可以在命令提示符中进入当前目录后执行：

```bat
start-local-windows.bat
```

脚本会分别安装两个项目的依赖，并启动：

- 3D 可视化项目：http://localhost:5173/
- 外层主站项目：http://localhost:5174/

打开 http://localhost:5174/ 后，进入“三维控制”页面即可看到嵌入的本地 3D 项目。

## 手动启动方式

如果不使用脚本，可以开两个终端：

终端 1：

```bash
cd projects/drone-orchard
npm ci
npm run dev -- --host 0.0.0.0 --port 5173
```

终端 2：

```bash
cd projects/mamba-agri-sim
npm ci
npm run dev -- --host 0.0.0.0 --port 5174
```

Windows 手动启动时同样可以使用上述命令，只需要在 `cmd` 或 PowerShell 中用 `cd` 进入对应目录即可。

## 注意事项

- 外层项目的“三维控制”页面通过 iframe 嵌入 `http://localhost:5173/`，所以必须先保证 `drone-orchard` 在 5173 端口运行。
- 本包不包含 `UAV_datas`、`alg/data`、`alg/outputs` 等数据集和算法实验输出。
- 如果端口被占用，请先关闭占用 5173 或 5174 的服务。
- Windows 需要先安装 Node.js 18 或更高版本，并确保 `npm` 命令可用。

