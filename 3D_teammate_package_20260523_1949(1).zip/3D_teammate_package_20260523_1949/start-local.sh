#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

start_app() {
  local name="$1"
  local dir="$2"
  local port="$3"

  (
    cd "$ROOT_DIR/projects/$dir"
    if [ ! -d node_modules ]; then
      echo "[$name] installing dependencies..."
      npm ci
    fi
    echo "[$name] starting on http://localhost:$port/"
    npm run dev -- --host 0.0.0.0 --port "$port"
  ) &
}

start_app "drone-orchard" "drone-orchard" 5173
start_app "mamba-agri-sim" "mamba-agri-sim" 5174

wait

