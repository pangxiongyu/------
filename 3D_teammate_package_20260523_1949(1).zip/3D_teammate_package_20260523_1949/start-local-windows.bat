@echo off
setlocal

set ROOT_DIR=%~dp0

start "drone-orchard 5173" cmd /k "cd /d "%ROOT_DIR%projects\drone-orchard" && if not exist node_modules npm ci && npm run dev -- --host 0.0.0.0 --port 5173"
start "mamba-agri-sim 5174" cmd /k "cd /d "%ROOT_DIR%projects\mamba-agri-sim" && if not exist node_modules npm ci && npm run dev -- --host 0.0.0.0 --port 5174"

echo 已启动两个终端窗口：
echo 3D 可视化项目: http://localhost:5173/
echo 外层主站项目: http://localhost:5174/
echo.
echo 请等待 npm 安装和 Vite 启动完成后，再打开 http://localhost:5174/
pause

