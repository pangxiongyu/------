export const NAV_ITEMS = [
  { label: '首页', path: '/', icon: 'home' },
  { label: '场景详情', path: '/scene-detail', icon: 'scene' },
  { label: '农业应用', path: '/applications', icon: 'apps' },
  { label: '三维控制', path: '/viewport-3d', icon: '3d' },
  { label: '数据分析', path: '/data-display', icon: 'chart' },
]
