import PageContainer from '../components/common/PageContainer'

export default function Viewport3DPage() {
  const local3DUrl = 'http://localhost:5173/'

  return (
    <PageContainer className="bg-slate-950">
      <div className="h-[calc(100vh-4rem)] p-3">
        <iframe
          src={local3DUrl}
          title="本地 3D 无人机可视化项目"
          className="h-full w-full rounded-2xl border border-white/10 bg-black"
          allow="fullscreen; autoplay; xr-spatial-tracking"
        />
      </div>
    </PageContainer>
  )
}
