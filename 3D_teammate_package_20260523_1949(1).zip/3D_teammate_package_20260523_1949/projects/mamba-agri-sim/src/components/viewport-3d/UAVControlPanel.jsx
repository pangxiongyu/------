import { HiCheckCircle, HiClock, HiPause, HiPlay, HiRefresh } from 'react-icons/hi'
import { DRONE_FLEET } from '../../data/droneFleet'
import UAVCard from './UAVCard'

export default function UAVControlPanel({ isRunning, progress, onStart, onPause, onReset }) {
  const isComplete = progress >= 100
  const statusText = isComplete ? '仿真完成' : isRunning ? '仿真运行中' : '仿真暂停'
  const StatusIcon = isComplete ? HiCheckCircle : HiClock

  return (
    <div className="bg-white/90 backdrop-blur-md rounded-2xl shadow-xl border border-white/40 p-6 h-full flex flex-col">
      <h2 className="text-xl font-black text-dark mb-1">三维无人机控制系统</h2>
      <p className="text-sm text-gray-400 mb-5">实时 UAV 状态监控 · 8 机编队</p>

      <div className="mb-5 rounded-2xl border border-agri-100 bg-gradient-to-br from-agri-50 to-emerald-50 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <StatusIcon className={`w-5 h-5 ${isComplete ? 'text-agri-600' : 'text-amber-500'}`} />
            <span className="text-sm font-bold text-dark">{statusText}</span>
          </div>
          <span className="text-sm font-black text-agri-700">{Math.round(progress)}%</span>
        </div>

        <div className="h-2.5 rounded-full bg-white/80 overflow-hidden border border-white">
          <div
            className="h-full rounded-full bg-gradient-to-r from-agri-400 to-emerald-600 transition-all duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="grid grid-cols-2 gap-2 mt-4">
          <button
            type="button"
            onClick={isRunning ? onPause : onStart}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-agri-500 px-3 py-2.5 text-sm font-bold text-white shadow-glow-sm transition-all hover:bg-agri-600 active:scale-95"
          >
            {isRunning ? <HiPause className="w-4 h-4" /> : <HiPlay className="w-4 h-4" />}
            {isRunning ? '暂停' : isComplete ? '重播' : '启动'}
          </button>
          <button
            type="button"
            onClick={onReset}
            className="flex items-center justify-center gap-1.5 rounded-xl border border-gray-200 bg-white/80 px-3 py-2.5 text-sm font-bold text-gray-600 transition-all hover:border-agri-200 hover:text-agri-600 active:scale-95"
          >
            <HiRefresh className="w-4 h-4" />
            重置
          </button>
        </div>
      </div>

      <div className="space-y-2 flex-1 overflow-y-auto">
        {DRONE_FLEET.map((drone) => (
          <UAVCard key={drone.id} drone={drone} />
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-gray-100">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-500">编队状态</span>
          <span className="font-bold text-agri-500">
            {DRONE_FLEET.filter((d) => d.status === 'active').length} 飞行中
          </span>
        </div>
        <div className="flex items-center justify-between text-sm mt-1">
          <span className="text-gray-500">平均电量</span>
          <span className="font-bold text-dark">
            {Math.round(DRONE_FLEET.reduce((s, d) => s + d.battery, 0) / DRONE_FLEET.length)}%
          </span>
        </div>
      </div>
    </div>
  )
}
